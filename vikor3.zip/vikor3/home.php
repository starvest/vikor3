<article class="hentry">
    <div class="page-header">
        <h1 class="entry-title">SPK VIKOR</h1>
    </div>
    <div class="entry-content">
        <p><h3>Selamat datang di aplikasi Sistem Pendukung Keputusan. 
        Aplikasi ini dapat digunakan untuk mengatasi permasalahan multikriteria 
        sistem yang kompleks yang berfokus pada ranking dan seleksi dari sebuah alternatif.
        Klik "Selanjutnya" untuk memulai.</h3></p>
    </div>
    <a href="?m=kriteria"><button class="btn btn-primary"><span class="glyphicon glyphicon-arrow-right"></span> Selanjutnya</button>
</article>